Emily Jackson and Nina Flaherty

This viz was run in Safari. 

After unzipping the folder, launch Terminal. Change directory into the HW6 folder. Then you'll want to create a local server to host the files by typing in "python -m SimpleHTTPServer 9999". Once you've done so, visit "localhost:9999" in your web browser.

 