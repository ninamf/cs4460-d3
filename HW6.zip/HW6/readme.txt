Emily Jackson and Nina Flaherty

This viz was run in Safari. 

After unzipping the folder. You'll want to create a local server to host the files. Once you've done so, you can click through to open the "d3Hw6.html" file. 
